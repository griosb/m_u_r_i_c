using System;
using System.Collections.Generic;
using System.IO;
using Avro;
using Avro.Generic;
using Avro.IO;
using Avro.File;

namespace MuricAvroGenerator
{
    class Program
    {
        // Nombre de archivo estándar: T<tipoentidad>_C<codigoentidad>_muric_<DDMMYYYY>
        private const string TipoEntidad = "1";
        private const string CodigoEntidad = "57";
        private const int CantidadArchivos = 5;

        private static readonly Random Rnd = new();

        // Schema AVRO: raíz único con los 3 insumos del módulo MURIC.
        // IMPORTANTE: Ajusta los nombres/tipos de campos al esquema oficial
        // MURIC_V_2.0.10 de la SFC antes de enviar información real.
        private const string MuricSchemaJson = @"{
  ""type"": ""record"",
  ""name"": ""MuricReport"",
  ""namespace"": ""co.gov.superfinanciera.muric"",
  ""fields"": [
    { ""name"": ""creditos"", ""type"": {
        ""type"": ""array"", ""items"": {
          ""type"": ""record"", ""name"": ""Credito"", ""fields"": [
            { ""name"": ""numero_credito"", ""type"": ""string"" },
            { ""name"": ""identificacion_deudor"", ""type"": ""string"" },
            { ""name"": ""tipo_identificacion"", ""type"": ""string"" },
            { ""name"": ""nombre_deudor"", ""type"": ""string"" },
            { ""name"": ""valor_inicial"", ""type"": ""double"" },
            { ""name"": ""saldo_capital"", ""type"": ""double"" },
            { ""name"": ""tasa_interes"", ""type"": ""double"" },
            { ""name"": ""fecha_desembolso"", ""type"": ""string"" },
            { ""name"": ""fecha_vencimiento"", ""type"": ""string"" },
            { ""name"": ""codigo_linea_credito"", ""type"": ""string"" }
          ]
        }
      }
    },
    { ""name"": ""atributos"", ""type"": {
        ""type"": ""array"", ""items"": {
          ""type"": ""record"", ""name"": ""Atributo"", ""fields"": [
            { ""name"": ""numero_credito"", ""type"": ""string"" },
            { ""name"": ""codigo_atributo"", ""type"": ""string"" },
            { ""name"": ""valor_atributo"", ""type"": ""string"" }
          ]
        }
      }
    },
    { ""name"": ""movimientos"", ""type"": {
        ""type"": ""array"", ""items"": {
          ""type"": ""record"", ""name"": ""Movimiento"", ""fields"": [
            { ""name"": ""numero_credito"", ""type"": ""string"" },
            { ""name"": ""tipo_movimiento"", ""type"": ""string"" },
            { ""name"": ""valor_movimiento"", ""type"": ""double"" },
            { ""name"": ""fecha_movimiento"", ""type"": ""string"" },
            { ""name"": ""descripcion"", ""type"": ""string"" }
          ]
        }
      }
    }
  ]
}";

        static void Main(string[] args)
        {
            Directory.CreateDirectory("salida");

            var schema = (RecordSchema)Schema.Parse(MuricSchemaJson);

            for (int i = 1; i <= CantidadArchivos; i++)
            {
                // Cada archivo con un periodo distinto: 01/08/2026 .. 05/08/2026
                var periodo = new DateTime(2026, 7, 31).AddDays(i);
                string nombreBase = $"T{TipoEntidad}_C{CodigoEntidad}_muric_{periodo:ddMMyyyy}";
                string ruta = Path.Combine("salida", $"{nombreBase}.avro");

                EscribirArchivo(schema, ruta, creditos: 1000, atributos: 3000, movimientos: 5000);
                Console.WriteLine($"Generado: {ruta}");
            }

            Console.WriteLine("\n¡Listo! Recuerda firmar digitalmente (*.p7z) antes de transmitir.");
        }

        private static void EscribirArchivo(RecordSchema schema, string ruta,
            int creditos, int atributos, int movimientos)
        {
            var record = new GenericRecord(schema)
            {
                ["creditos"] = GenerarCreditos(creditos),
                ["atributos"] = GenerarAtributos(atributos),
                ["movimientos"] = GenerarMovimientos(movimientos)
            };

            // Codec Snappy: requisito según el documento MURIC
            using var stream = new FileStream(ruta, FileMode.Create);
            using var writer = DataFileWriter<GenericRecord>.OpenWriter(
                new GenericDatumWriter<GenericRecord>(schema), stream,
                Codec.CreateCodec(Codec.Type.Snappy));
            writer.Append(record);
            writer.Flush();
        }

        private static List<GenericRecord> GenerarCreditos(int cantidad)
        {
            var arraySchema = (ArraySchema)((RecordSchema)Schema.Parse(MuricSchemaJson))
                .Fields.Find(f => f.Name == "creditos").Schema;
            var recSchema = (RecordSchema)arraySchema.ItemSchema;

            var lista = new List<GenericRecord>(cantidad);
            for (int i = 0; i < cantidad; i++)
            {
                lista.Add(new GenericRecord(recSchema)
                {
                    ["numero_credito"] = $"CRED-{Rnd.Next(100000, 999999)}",
                    ["identificacion_deudor"] = $"{Rnd.Next(10, 99)}{Rnd.Next(10000000, 99999999)}",
                    ["tipo_identificacion"] = Elegir("CC", "NIT", "CE", "PAS"),
                    ["nombre_deudor"] = $"Deudor de Prueba {i}",
                    ["valor_inicial"] = Math.Round(Rnd.NextDouble() * 500_000_000, 2),
                    ["saldo_capital"] = Math.Round(Rnd.NextDouble() * 200_000_000, 2),
                    ["tasa_interes"] = Math.Round(Rnd.NextDouble() * 30, 2),
                    ["fecha_desembolso"] = $"{FechaAleatoria():yyyy-MM-dd}",
                    ["fecha_vencimiento"] = $"{FechaAleatoria(2026, 2035):yyyy-MM-dd}",
                    ["codigo_linea_credito"] = $"LC{Rnd.Next(100, 999)}"
                });
            }
            return lista;
        }

        private static List<GenericRecord> GenerarAtributos(int cantidad)
        {
            var arraySchema = (ArraySchema)((RecordSchema)Schema.Parse(MuricSchemaJson))
                .Fields.Find(f => f.Name == "atributos").Schema;
            var recSchema = (RecordSchema)arraySchema.ItemSchema;

            var lista = new List<GenericRecord>(cantidad);
            for (int i = 0; i < cantidad; i++)
            {
                lista.Add(new GenericRecord(recSchema)
                {
                    ["numero_credito"] = $"CRED-{Rnd.Next(100000, 999999)}",
                    ["codigo_atributo"] = $"ATR-{Rnd.Next(1000, 9999)}",
                    ["valor_atributo"] = $"VAL-{Rnd.Next(10000, 99999)}"
                });
            }
            return lista;
        }

        private static List<GenericRecord> GenerarMovimientos(int cantidad)
        {
            var arraySchema = (ArraySchema)((RecordSchema)Schema.Parse(MuricSchemaJson))
                .Fields.Find(f => f.Name == "movimientos").Schema;
            var recSchema = (RecordSchema)arraySchema.ItemSchema;

            var lista = new List<GenericRecord>(cantidad);
            for (int i = 0; i < cantidad; i++)
            {
                lista.Add(new GenericRecord(recSchema)
                {
                    ["numero_credito"] = $"CRED-{Rnd.Next(100000, 999999)}",
                    ["tipo_movimiento"] = Elegir("PAGO", "ABONO", "DESEMBOLSO", "MORA", "CASTIGO"),
                    ["valor_movimiento"] = Math.Round(Rnd.NextDouble() * 10_000_000, 2),
                    ["fecha_movimiento"] = $"{FechaAleatoria():yyyy-MM-dd}",
                    ["descripcion"] = $"Movimiento de prueba {i}"
                });
            }
            return lista;
        }

        private static DateTime FechaAleatoria(int anioInicio = 2020, int anioFin = 2026)
            => new DateTime(Rnd.Next(anioInicio, anioFin + 1), Rnd.Next(1, 13), Rnd.Next(1, 28));

        private static string Elegir(params string[] opciones)
            => opciones[Rnd.Next(opciones.Length)];
    }
}
