# MuricAvroGenerator

Generador de archivos AVRO de prueba para el módulo MURIC de la SFC,
según el Documento Técnico "Servicio Captura Información MURIC" (Agosto 2026).

## Contenido

- `MuricAvroGenerator.csproj` — proyecto .NET 8 (consola)
- `Program.cs` — código fuente con el schema AVRO y la generación de datos
- `archivos-prueba/` — 5 archivos AVRO ya generados (compresión Snappy, codificación UTF-8)

## Estructura del archivo AVRO

Registro raíz único con 3 arrays (los 3 insumos MURIC):

| Array        | Registros por archivo |
|--------------|-----------------------|
| `creditos`   | 1.000                 |
| `atributos`  | 3.000                 |
| `movimientos`| 5.000                 |

## Nombramiento estándar

    T<tipoentidad>_C<codigoentidad>_muric_<DDMMYYYY>.avro

Ejemplo: `T1_C57_muric_01082026.avro`

## Uso

    dotnet restore
    dotnet run

Los archivos se generan en `./salida/`.

## Advertencias

1. El schema incluido es de EJEMPLO. Antes de transmitir información real,
   reemplázalo por el esquema oficial MURIC_V_2.0.10 de la SFC para que
   pase la validación de esquema (VALIDACION_ESQUEMA).
2. Los archivos .avro generados NO están firmados. Para la transmisión deben
   envolverse en contenedor .p7z firmado por el representante legal, p. ej.:

       openssl smime -sign -in T1_C57_muric_01082026.avro \
           -out T1_C57_muric_01082026.avro.p7z \
           -signer certificado.crt -inkey clave.key -outform DER

3. Para la API REST calcula el SHA-256 (minúsculas) del .avro.p7z firmado.
4. Transmisión: ventana habilitada, un solo canal (API REST o Superfinanciera
   Archivos), usuario con rol "Transmisión MURIC".
